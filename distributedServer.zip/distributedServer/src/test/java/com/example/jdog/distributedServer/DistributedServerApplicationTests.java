package com.example.jdog.distributedServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributedServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
