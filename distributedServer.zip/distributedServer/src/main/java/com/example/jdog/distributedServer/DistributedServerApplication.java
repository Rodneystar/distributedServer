package com.example.jdog.distributedServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DistributedServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DistributedServerApplication.class, args);
	}

}
